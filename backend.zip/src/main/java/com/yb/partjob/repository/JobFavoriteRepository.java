package com.yb.partjob.repository;

import com.yb.partjob.model.JobFavorite;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface JobFavoriteRepository extends JpaRepository<JobFavorite, Long> {
    Page<JobFavorite> findByStudentId(Long studentId, Pageable pageable);

    Optional<JobFavorite> findByStudentIdAndJobId(Long studentId, Long jobId);

    boolean existsByStudentIdAndJobId(Long studentId, Long jobId);

    long countByStudentId(Long studentId);

    void deleteByStudentIdAndJobId(Long studentId, Long jobId);
}
